#include <bits/stdc++.h>
using namespace std;

void functionxyz(int n){
	if(n==0){
        return;
    }
	functionxyz(n-1);
	cout << n << " ";
}

int addnos(int n,int arr[]){
	if(n==0) 
	 return 0;

	return  addnos(n-1,arr) + arr[n-1] ;  
}

int power(int n,int p){
	if(p == 0)
	 return 1;

	return n*power(n,p-1); 
}

bool checkarr(int n,int arr[]){
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if(arr[i]<arr[j]){
				return true; 
			}
		}
	}
	return false;
}

int sum_nos(int n){
	if(n==0){
		return 0;
	}
	return n + sum_nos(n-1);
}

bool palindromeCheck(string s,int start,int end){
	if(start>=end){
        return true;
    }

    return (s[start] == s[end]) && palindromeCheck(s,start+1,end-1);
}

int sum_of_digits(int n){
    if(n==0)
     return 0;

    return n%10 + sum_of_digits(n/10); 
}


int eggBreakProblem(int e,int floor){
	if(n>=1 && n<=49){
		return 
	}
}

int main()
{
	// int n = 5;
	// int arr[n] = {1,2,3,6,5};
	// cout << checkarr(n,arr);
	//cout << sum_nos(4);
    //cout << palindromeCheck("abccdba",0,3);
    cout << sum_of_digits(25301);
	return 0;
}